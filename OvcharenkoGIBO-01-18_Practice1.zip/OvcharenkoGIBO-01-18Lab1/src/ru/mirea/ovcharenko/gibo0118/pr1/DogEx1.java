package ru.mirea.ovcharenko.gibo0118.pr1;

public class DogEx1 {
    public static void main(String[] args) {
        Dog c1 = new Dog(45,"Charlie");
        System.out.println(c1);
        c1.setName("Bobby");
        c1.setWeight(5.0);
        System.out.println(c1);
    }
}
