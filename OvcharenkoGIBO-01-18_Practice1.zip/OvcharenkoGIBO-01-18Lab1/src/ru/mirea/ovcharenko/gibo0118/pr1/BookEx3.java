package ru.mirea.ovcharenko.gibo0118.pr1;

public class BookEx3 {
    public static void main(String[] args) {
        Book c3 = new Book( 200, "Pushkin");
        System.out.println(c3);
        c3.setAuthor("Lermontov");
        c3.setPages(111);
        System.out.println(c3);
    }
}
