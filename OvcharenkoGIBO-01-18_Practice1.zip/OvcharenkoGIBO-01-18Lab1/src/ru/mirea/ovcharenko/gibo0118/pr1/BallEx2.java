package ru.mirea.ovcharenko.gibo0118.pr1;

public class BallEx2 {
    public static void main(String[] args) {
        Ball c2 = new Ball(50.0,"Adidas");
        System.out.println(c2);
        c2.setBrand("Nike");
        c2.setDiameter(25.5);
        System.out.println(c2);
    }
}
