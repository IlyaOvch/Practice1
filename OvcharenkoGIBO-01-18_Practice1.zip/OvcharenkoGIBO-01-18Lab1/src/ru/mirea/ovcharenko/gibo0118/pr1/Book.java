package ru.mirea.ovcharenko.gibo0118.pr1;
import java.lang.*;

public class Book {
    private int Pages;
    private String Author;

    public Book(int pages, String author) {
        Pages = pages;
        Author = author;
    }

    public Book(int pages) {
        Pages = pages;
    }

    public int getPages() {
        return Pages;
    }

    public void setPages(int pages) {
        Pages = pages;
    }

    public String getAuthor() {
        return Author;
    }

    public void setAuthor(String author) {
        Author = author;
    }

    @Override
    public String toString() {
        return "Book{" +
                "Pages=" + Pages +
                ", Author='" + Author + '\'' +
                '}';
    }
}
