package ru.mirea.ovcharenko.gibo0118.pr1;
import java.lang.*;


public class Ball {
    private double Diameter;
    private String Brand;

    public Ball(double diameter, String brand) {
        Diameter = diameter;
        Brand = brand;
    }

    public Ball(double diameter) {
        Diameter = diameter;
    }

    public double getDiameter() {
        return Diameter;
    }

    public void setDiameter(double diameter) {
        Diameter = diameter;
    }

    public String getBrand() {
        return Brand;
    }

    public void setBrand(String brand) {
        Brand = brand;
    }

    @Override
    public String toString() {
        return "Ball{" +
                "Diameter=" + Diameter +
                ", Brand='" + Brand + '\'' +
                '}';
    }
}
