package ru.mirea.ovcharenko.gibo0118.pr1;
import java.lang.*;


public class Dog {
    private double weight;
    private String name;

    public Dog(double weight, String name) {
        this.weight = weight;
        this.name = name;
    }

    public Dog(double weight) {
        this.weight = weight;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "weight=" + weight +
                ", name='" + name + '\'' +
                '}';
    }
}